#!/bin/bash
# 
# BEGIN COPYRIGHT
# *************************************************************************
# THIS PRODUCT CONTAINS RESTRICTED MATERIALS OF IBM
# 5725-G75 5725-G76
# (C) Copyright IBM Corp. 2012 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# *************************************************************************
# END COPYRIGHT
#
#By Djalma Saraiva
#set -x


./DesativaSnapshotPS.sh
if [ "$?" == "0" ]; then
        echo "[`date`]Desativação concluída."
    else
        echo "[`date`]Desativação falhou."
fi

./StopSnapshotPS.sh
if [ "$?" == "0" ]; then
        echo "[`date`]Stop de snapshots concluído."
    else
        echo "[`date`]Stop de snapshots falhou."
fi

./UndeploySnapshotPS.sh
if [ "$?" == "0" ]; then
        echo "[`date`]Undeploy de snapshots concluído."
    else
        echo "[`date`]Undeploy de snapshots falhou."
fi

./DeleteProcessInstancePS.sh
if [ "$?" == "0" ]; then
        echo "[`date`]Exclusão de instancias concluída."
    else
        echo "[`date`]Exclusão de instancias falhou."
fi