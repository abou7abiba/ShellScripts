#!/bin/bash
# 
# BEGIN COPYRIGHT
# *************************************************************************
# THIS PRODUCT CONTAINS RESTRICTED MATERIALS OF IBM
# 5725-G75 5725-G76
# (C) Copyright IBM Corp. 2012 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# *************************************************************************
# END COPYRIGHT
#
#By Djalma Saraiva
#set -x

HOST_ADR=
PORT_NUMBER=
WS_USER=wsadmin
PSW_WS_USER=
WSADMIN_PATH=/opt/IBM/BPM/profiles/PSNode01/bin
LIST_PROCESS_OUT=/tmp/PS_ACRONYMS.log
SNAPSHOT_OUT=/tmp/PS_SNAPINFO.log
SNAPSHOTLIST_OUT=/tmp/PS_SNAPLIST.log
SNAPSHOTSTOP_OUT=/tmp/PS_SNAPACTIVE.log
WAS_HOME=/opt/IBM/BPM
WAS_PRODUCT=${WAS_HOME}/properties/version/WAS.product
WAS_VERSION=`cat ${WAS_PRODUCT} | grep '<version>'|sed 's/[<>]/ /g' | awk '{ print $2 }'`
LOG_FILE=/tmp/cleanup.log
rm -f  $LIST_PROCESS_OUT $SNAPSHOT_OUT $SNAPSHOTLIST_OUT $SNAPSHOTACTIVE_OUT   
clear
echo "============ Cleanup Process Server ============"  
echo "WAS Version: $WAS_VERSION"		  	   
echo "Start date - time  `date`"               	  
echo "================================================"  	  
echo " "									   	  
echo "[`date`]Carregando lista de Snapshots"   	  
#The following command list all process applications and toolkits on the server.	
	$WSADMIN_PATH/wsadmin.sh -conntype SOAP -port $PORT_NUMBER -host $HOST_ADR  -user wsadmin -password $PSW_WS_USER -lang jython \
		-c "AdminTask.BPMListProcessApplications()" > $LIST_PROCESS_OUT

#Filter	all acronyms on the server.	
	sed 's/\\n/\
/g' $LIST_PROCESS_OUT  | grep 'Acronym:' | sed "s/Acronym://g" > $SNAPSHOT_OUT
	ACRONYMS_LIST=`cat $SNAPSHOT_OUT`

echo "[`date`]Lista de acronimos finalizada" 	  

#This command lists information about a process application on a Process Center or a Process Server. 
	for acronym in ${ACRONYMS_LIST}; do
		
		echo "[`date`]Analisando snapshot $acronym"
		$WSADMIN_PATH/wsadmin.sh -conntype SOAP -port $PORT_NUMBER -host $HOST_ADR  -user wsadmin -password $PSW_WS_USER -lang jython \
			-c "AdminTask.BPMShowProcessApplication('[-containerAcronym $acronym]')" > $SNAPSHOTLIST_OUT

		#Filtra apenas os snapshot que poderão sem parados
		sed 's/\\n/\
/g' $SNAPSHOTLIST_OUT  | sed 's/\\t//g' | grep -p "\[Inactive\]" | grep -p "Is Default: false" | grep -p "No of running instances: 0" | grep -p "Capability\[Advanced\]"| grep -E 'Acronym: [0-9]' | sed "s/Acronym://g" | sed "s/\\\t//g" | awk '{ print $1 }' | cat | xargs > $SNAPSHOTSTOP_OUT
		
		SNAPSHOTACRONYM_LIST=`cat $SNAPSHOTSTOP_OUT`
			
		if [ "$SNAPSHOTACRONYM_LIST" != "" ]; then
			echo "Versões afetadas: $SNAPSHOTACRONYM_LIST"
			for container in ${SNAPSHOTACRONYM_LIST}; do
				$WSADMIN_PATH/wsadmin.sh -conntype SOAP -port $PORT_NUMBER -host $HOST_ADR  -user wsadmin -password $PSW_WS_USER -lang jython \
				-c "AdminTask.BPMStop('[-containerAcronym $acronym -containerSnapshotAcronym [$container]]')"
			done
			
		fi
	done


echo "======================================"
echo "End : `date`"         	  
echo "======================================" 




